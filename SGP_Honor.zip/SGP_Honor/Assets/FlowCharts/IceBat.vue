<!-- Tufts VUE 2.3.1 concept-map (IceBat.vue) 2014-10-31 -->
<!-- Tufts VUE: http://vue.tufts.edu/ -->
<!-- Do Not Remove: VUE mapping @version(1.1) jar:file:/C:/Program%20Files%20(x86)/VUE/VUE.jar!/tufts/vue/resources/lw_mapping_1_1.xml -->
<!-- Do Not Remove: Saved date Fri Oct 31 16:13:13 EDT 2014 by Jordan on platform Windows 8 6.2 in JVM 1.7.0_40-b43 -->
<!-- Do Not Remove: Saving version @(#)VUE: built May 6 2009 at 1148 by vue on Linux 2.4.21-57.EL i386 JVM 1.5.0_06-b05 -->
<?xml version="1.0" encoding="US-ASCII"?>
<LW-MAP xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:noNamespaceSchemaLocation="none" ID="0" label="IceBat.vue"
    x="0.0" y="0.0" width="1.4E-45" height="1.4E-45" strokeWidth="0.0" autoSized="false">
    <resource referenceCreated="1414786394078"
        spec="C:\Users\fullsail\Documents\IceBat.vue" type="1" xsi:type="URLResource">
        <title>IceBat.vue</title>
        <property key="File" value="C:\Users\fullsail\Documents\IceBat.vue"/>
    </resource>
    <fillColor>#FFFFFF</fillColor>
    <strokeColor>#404040</strokeColor>
    <textColor>#000000</textColor>
    <font>SansSerif-plain-14</font>
    <metadata-list category-list-size="1" other-list-size="0"
        ontology-list-size="0" RCategoryListSize="0">
        <ontology-list-string></ontology-list-string>
        <metadata xsi:type="vue-metadata-element">
            <value></value>
            <key>http://vue.tufts.edu/vue.rdfs#none</key>
            <type>1</type>
        </metadata>
    </metadata-list>
    <URIString>http://vue.tufts.edu/rdf/resource/67d727ec0a14182f0027575924bdd817</URIString>
    <child ID="2" label="Ice Bat" layerID="1" x="64.0" y="64.0"
        width="263.0" height="70.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#F2AE45</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67d727ed0a14182f00275759321d5a16</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="3" label="Movement" layerID="1" x="505.0" y="84.0"
        width="102.0" height="23.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#30D643</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67d727ee0a14182f002757596159e81b</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="4" label="Idle" layerID="1" x="113.0" y="218.0"
        width="162.0" height="37.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#30D643</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67d727ef0a14182f00275759e1c9f57b</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="5" label="Move to player" layerID="1" x="391.0" y="264.0"
        width="111.0" height="41.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#30D643</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67d727f00a14182f00275759135c4fd1</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="6" label="Return to start position" layerID="1" x="574.0"
        y="219.0" width="208.0" height="39.0" strokeWidth="1.0"
        autoSized="false" xsi:type="node">
        <fillColor>#30D643</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67d727f10a14182f0027575918f87d6e</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="9" label="Check Range" layerID="1" x="402.0" y="433.0"
        width="86.0" height="36.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#30D643</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67d727f20a14182f002757599e86bd67</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="12" label="Player Nearby" layerID="1" x="272.00723"
        y="250.92413" width="119.50256" height="23.527206"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67d727f30a14182f0027575958320755</URIString>
        <point1 x="272.50723" y="251.42415"/>
        <point2 x="391.0098" y="273.95135"/>
        <ID1 xsi:type="node">4</ID1>
        <ID2 xsi:type="node">5</ID2>
    </child>
    <child ID="13" label="Moving to player" layerID="1" x="405.73874"
        y="304.5" width="80.0" height="129.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67d727f40a14182f002757592d8c5ff7</URIString>
        <point1 x="446.3153" y="305.0"/>
        <point2 x="445.16217" y="433.0"/>
        <ID1 xsi:type="node">5</ID1>
        <ID2 xsi:type="node">9</ID2>
    </child>
    <child ID="14" label="Still in range" layerID="1" x="323.5608"
        y="304.5" width="88.34598" height="129.23492" strokeWidth="1.0"
        autoSized="false" controlCount="1" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67d727f50a14182f00275759a4b151e5</URIString>
        <point1 x="410.8364" y="433.23492"/>
        <point2 x="411.40677" y="305.0"/>
        <ID1 xsi:type="node">9</ID1>
        <ID2 xsi:type="node">5</ID2>
        <ctrlPoint0 x="295.0" y="373.0" xsi:type="point"/>
    </child>
    <child ID="15" label="Out of range" layerID="1" x="464.23645"
        y="257.5" width="192.8823" height="176.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67d727f60a14182f00275759baf19e5f</URIString>
        <point1 x="464.73648" y="433.0"/>
        <point2 x="656.6188" y="258.0"/>
        <ID1 xsi:type="node">9</ID1>
        <ID2 xsi:type="node">6</ID2>
    </child>
    <child ID="16" label="Back at start" layerID="1" x="274.5"
        y="230.45248" width="300.0" height="14.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67d727f70a14182f0027575949a25212</URIString>
        <point1 x="574.0" y="238.07025"/>
        <point2 x="275.0" y="236.83472"/>
        <ID1 xsi:type="node">6</ID1>
        <ID2 xsi:type="node">4</ID2>
    </child>
    <child ID="17" label="Start" layerID="1" x="108.0" y="136.0"
        width="167.0" height="62.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#EA2218</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67d727f80a14182f00275759aabdb5f7</URIString>
        <shape xsi:type="shield"/>
    </child>
    <child ID="18" layerID="1" x="192.08609" y="196.69336"
        width="1.7484436" height="21.80664" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67d727f80a14182f00275759bf17cac5</URIString>
        <point1 x="192.58609" y="197.19336"/>
        <point2 x="193.33453" y="218.0"/>
        <ID1 xsi:type="node">17</ID1>
        <ID2 xsi:type="node">4</ID2>
    </child>
    <layer ID="1" label="Layer 1" x="0.0" y="0.0" width="1.4E-45"
        height="1.4E-45" strokeWidth="0.0" autoSized="false">
        <metadata-list category-list-size="0" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67d727f90a14182f00275759e441f9f9</URIString>
    </layer>
    <userZoom>1.0</userZoom>
    <userOrigin x="-12.0" y="-12.0"/>
    <presentationBackground>#202020</presentationBackground>
    <PathwayList currentPathway="0" revealerIndex="-1">
        <pathway ID="0" label="Untitled Pathway" x="0.0" y="0.0"
            width="1.4E-45" height="1.4E-45" strokeWidth="0.0"
            autoSized="false" currentIndex="-1" open="true">
            <strokeColor>#B3993333</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="0" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/67d727fe0a14182f00275759d61865aa</URIString>
            <masterSlide ID="19" x="0.0" y="0.0" width="800.0"
                height="600.0" locked="true" strokeWidth="0.0" autoSized="false">
                <fillColor>#000000</fillColor>
                <strokeColor>#404040</strokeColor>
                <textColor>#000000</textColor>
                <font>SansSerif-plain-14</font>
                <metadata-list category-list-size="0"
                    other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                    <ontology-list-string></ontology-list-string>
                </metadata-list>
                <URIString>http://vue.tufts.edu/rdf/resource/67d7291e0a14182f002757591d3eb5c0</URIString>
                <titleStyle ID="20" label="Header" x="335.5" y="172.5"
                    width="129.0" height="55.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-36</font>
                    <metadata-list category-list-size="0"
                        other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                        <ontology-list-string></ontology-list-string>
                    </metadata-list>
                    <URIString>http://vue.tufts.edu/rdf/resource/67d7291e0a14182f0027575982e9d4a5</URIString>
                    <shape xsi:type="rectangle"/>
                </titleStyle>
                <textStyle ID="21" label="Slide Text" x="346.5"
                    y="281.5" width="107.0" height="37.0"
                    strokeWidth="0.0" autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-22</font>
                    <metadata-list category-list-size="0"
                        other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                        <ontology-list-string></ontology-list-string>
                    </metadata-list>
                    <URIString>http://vue.tufts.edu/rdf/resource/67d7291f0a14182f002757599de7d131</URIString>
                    <shape xsi:type="rectangle"/>
                </textStyle>
                <linkStyle ID="22" label="Links" x="373.5" y="384.0"
                    width="53.0" height="32.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#B3BFE3</textColor>
                    <font>Gill Sans-plain-18</font>
                    <metadata-list category-list-size="0"
                        other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                        <ontology-list-string></ontology-list-string>
                    </metadata-list>
                    <URIString>http://vue.tufts.edu/rdf/resource/67d7291f0a14182f00275759512304ff</URIString>
                    <shape xsi:type="rectangle"/>
                </linkStyle>
            </masterSlide>
        </pathway>
    </PathwayList>
    <date>2014-10-31</date>
    <mapFilterModel/>
    <modelVersion>5</modelVersion>
    <saveLocation>C:\Users\fullsail\Documents</saveLocation>
    <saveFile>C:\Users\fullsail\Documents\IceBat.vue</saveFile>
</LW-MAP>
