<!-- Tufts VUE 2.3.1 concept-map (YetiSmall.vue) 2014-10-31 -->
<!-- Tufts VUE: http://vue.tufts.edu/ -->
<!-- Do Not Remove: VUE mapping @version(1.1) jar:file:/C:/Program%20Files%20(x86)/VUE/VUE.jar!/tufts/vue/resources/lw_mapping_1_1.xml -->
<!-- Do Not Remove: Saved date Fri Oct 31 15:26:31 EDT 2014 by Jordan on platform Windows 8 6.2 in JVM 1.7.0_40-b43 -->
<!-- Do Not Remove: Saving version @(#)VUE: built May 6 2009 at 1148 by vue on Linux 2.4.21-57.EL i386 JVM 1.5.0_06-b05 -->
<?xml version="1.0" encoding="US-ASCII"?>
<LW-MAP xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:noNamespaceSchemaLocation="none" ID="0" label="YetiSmall.vue"
    x="0.0" y="0.0" width="1.4E-45" height="1.4E-45" strokeWidth="0.0" autoSized="false">
    <resource referenceCreated="1414783592114"
        spec="C:\Users\fullsail\Desktop\YetiSmall.vue" type="1" xsi:type="URLResource">
        <title>YetiSmall.vue</title>
        <property key="File" value="C:\Users\fullsail\Desktop\YetiSmall.vue"/>
    </resource>
    <fillColor>#FFFFFF</fillColor>
    <strokeColor>#404040</strokeColor>
    <textColor>#000000</textColor>
    <font>SansSerif-plain-14</font>
    <metadata-list category-list-size="1" ontology-list-size="0"
        other-list-size="0" RCategoryListSize="0">
        <ontology-list-string></ontology-list-string>
        <metadata xsi:type="vue-metadata-element">
            <value></value>
            <key>http://vue.tufts.edu/vue.rdfs#none</key>
            <type>1</type>
        </metadata>
    </metadata-list>
    <URIString>http://vue.tufts.edu/rdf/resource/67ac66c00a14182f00e1cb28d7355178</URIString>
    <child ID="2" label="Yeti" layerID="1" x="-618.0" y="-426.5"
        width="195.0" height="95.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#F2AE45</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67ac66c10a14182f00e1cb284b7955c3</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="3" label="Movement" layerID="1" x="-171.0" y="-391.5"
        width="132.0" height="23.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#30D643</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67ac66c30a14182f00e1cb280ebb4edf</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="4" label="Attack" layerID="1" x="-169.0" y="-355.5"
        width="127.0" height="23.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#EA2218</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67ac66c40a14182f00e1cb289e2058bf</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="5" label="Return to start position" layerID="1" x="298.0"
        y="-120.5" width="135.0" height="23.0" strokeWidth="1.0"
        autoSized="true" xsi:type="node">
        <fillColor>#30D643</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67ac66c50a14182f00e1cb28a677e9b4</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="6" label="Move towards player" layerID="1" x="-591.0"
        y="-204.5" width="132.0" height="23.0" strokeWidth="1.0"
        autoSized="false" xsi:type="node">
        <fillColor>#30D643</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67ac66c50a14182f00e1cb283810f0bf</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="7" label="Idle" layerID="1" x="-588.0" y="-278.5"
        width="132.0" height="23.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#30D643</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67ac66c60a14182f00e1cb28e3b7fa2b</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="9" label="Wait" layerID="1" x="-277.0" y="-4.5"
        width="127.0" height="23.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#EA2218</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67ac66c70a14182f00e1cb283119ddea</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="10" label="Attack" layerID="1" x="15.0" y="-174.5"
        width="127.0" height="23.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#EA2218</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67ac66d50a14182f00e1cb283373d045</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="11" label="Check Cooldowns" layerID="1" x="-277.0"
        y="-204.5" width="127.0" height="23.0" strokeWidth="1.0"
        autoSized="false" xsi:type="node">
        <fillColor>#EA2218</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67ac66d50a14182f00e1cb287f4cf1d6</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="12" label="Check Aggro" layerID="1" x="299.0" y="-203.5"
        width="132.0" height="23.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#30D643</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67ac66d70a14182f00e1cb28c114308b</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="14" label="Is player in aggro range" layerID="1"
        x="-581.0" y="-256.0" width="115.0" height="52.0"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67ac66d80a14182f00e1cb287abea7f6</URIString>
        <point1 x="-522.46625" y="-255.5"/>
        <point2 x="-524.5338" y="-204.5"/>
        <ID1 xsi:type="node">7</ID1>
        <ID2 xsi:type="node">6</ID2>
    </child>
    <child ID="15" label="Player in attack range" layerID="1" x="-459.5"
        y="-200.0" width="183.0" height="14.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67ac66d90a14182f00e1cb2801e973ee</URIString>
        <point1 x="-459.0" y="-193.0"/>
        <point2 x="-277.0" y="-193.0"/>
        <ID1 xsi:type="node">6</ID1>
        <ID2 xsi:type="node">11</ID2>
    </child>
    <child ID="17" label="Attack on CD" layerID="1" x="-245.5"
        y="-182.0" width="64.0" height="178.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67ac66da0a14182f00e1cb28f3bf4a50</URIString>
        <point1 x="-213.5" y="-181.5"/>
        <point2 x="-213.5" y="-4.5"/>
        <ID1 xsi:type="node">11</ID1>
        <ID2 xsi:type="node">9</ID2>
    </child>
    <child ID="19" label="check again" layerID="1" x="-197.83333"
        y="-182.0" width="94.959854" height="178.0" strokeWidth="1.0"
        autoSized="false" controlCount="1" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67ac66da0a14182f00e1cb28fb16e684</URIString>
        <point1 x="-196.16061" y="-4.5"/>
        <point2 x="-197.33333" y="-181.5"/>
        <ID1 xsi:type="node">9</ID1>
        <ID2 xsi:type="node">11</ID2>
        <ctrlPoint0 x="-68.0" y="-89.5" xsi:type="point"/>
    </child>
    <child ID="24" label="off CD" layerID="1" x="-151.94843"
        y="-187.12485" width="168.89682" height="18.24968"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67ac66e00a14182f00e1cb285710d550</URIString>
        <point1 x="-151.44843" y="-186.62483"/>
        <point2 x="16.448402" y="-169.37515"/>
        <ID1 xsi:type="node">11</ID1>
        <ID2 xsi:type="node">10</ID2>
    </child>
    <child ID="25" label="Player still in range" layerID="1"
        x="-191.38591" y="-182.0" width="232.78477" height="46.5"
        strokeWidth="1.0" autoSized="false" controlCount="1"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67ac66e10a14182f00e1cb28466df78f</URIString>
        <point1 x="40.898876" y="-151.5"/>
        <point2 x="-190.88591" y="-181.5"/>
        <ID1 xsi:type="node">10</ID1>
        <ID2 xsi:type="node">11</ID2>
        <ctrlPoint0 x="-67.0" y="-118.5" xsi:type="point"/>
    </child>
    <child ID="26" label="Player moved away" layerID="1" x="140.11105"
        y="-185.97614" width="160.93764" height="17.189148"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67ac66e20a14182f00e1cb28c3ad2d1a</URIString>
        <point1 x="140.61104" y="-169.28699"/>
        <point2 x="300.54868" y="-185.47614"/>
        <ID1 xsi:type="node">10</ID1>
        <ID2 xsi:type="node">12</ID2>
    </child>
    <child ID="27" label="Player In Aggro range" layerID="1" x="-150.5"
        y="-199.50215" width="450.0" height="14.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67ac66e20a14182f00e1cb2800ee53fa</URIString>
        <point1 x="299.0" y="-192.11407"/>
        <point2 x="-150.0" y="-192.89023"/>
        <ID1 xsi:type="node">12</ID1>
        <ID2 xsi:type="node">11</ID2>
    </child>
    <child ID="28" label="Player out of aggro range" layerID="1"
        x="303.25" y="-181.0" width="124.0" height="61.0"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67ac66e30a14182f00e1cb285c6aaac9</URIString>
        <point1 x="365.06927" y="-180.5"/>
        <point2 x="365.43073" y="-120.5"/>
        <ID1 xsi:type="node">12</ID1>
        <ID2 xsi:type="node">5</ID2>
    </child>
    <child ID="31" label="Back to Idle" layerID="1" x="328.0" y="-46.5"
        width="74.0" height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#30D643</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67ac66e40a14182f00e1cb2898351485</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="32" label="Back at starting pos" layerID="1" x="316.75"
        y="-98.0" width="97.0" height="52.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67ac66e40a14182f00e1cb28f4a91b90</URIString>
        <point1 x="365.4223" y="-97.5"/>
        <point2 x="365.0777" y="-46.5"/>
        <ID1 xsi:type="node">5</ID1>
        <ID2 xsi:type="node">31</ID2>
    </child>
    <layer ID="1" label="Layer 1" x="0.0" y="0.0" width="1.4E-45"
        height="1.4E-45" strokeWidth="0.0" autoSized="false">
        <metadata-list category-list-size="0" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67ac66e50a14182f00e1cb28746b4d89</URIString>
    </layer>
    <userZoom>1.0</userZoom>
    <userOrigin x="-2232.0" y="-449.5"/>
    <presentationBackground>#202020</presentationBackground>
    <PathwayList currentPathway="0" revealerIndex="-1">
        <pathway ID="0" label="Untitled Pathway" x="0.0" y="0.0"
            width="1.4E-45" height="1.4E-45" strokeWidth="0.0"
            autoSized="false" currentIndex="-1" open="true">
            <strokeColor>#B3993333</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="0" ontology-list-size="0"
                other-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/67ac66e50a14182f00e1cb28c9697a35</URIString>
            <masterSlide ID="33" x="0.0" y="0.0" width="800.0"
                height="600.0" locked="true" strokeWidth="0.0" autoSized="false">
                <fillColor>#000000</fillColor>
                <strokeColor>#404040</strokeColor>
                <textColor>#000000</textColor>
                <font>SansSerif-plain-14</font>
                <metadata-list category-list-size="0"
                    ontology-list-size="0" other-list-size="0" RCategoryListSize="0">
                    <ontology-list-string></ontology-list-string>
                </metadata-list>
                <URIString>http://vue.tufts.edu/rdf/resource/67ac67f00a14182f00e1cb28b066a0a7</URIString>
                <titleStyle ID="34" label="Header" x="335.5" y="172.5"
                    width="129.0" height="55.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-36</font>
                    <metadata-list category-list-size="0"
                        ontology-list-size="0" other-list-size="0" RCategoryListSize="0">
                        <ontology-list-string></ontology-list-string>
                    </metadata-list>
                    <URIString>http://vue.tufts.edu/rdf/resource/67ac67f10a14182f00e1cb28ccef6b29</URIString>
                    <shape xsi:type="rectangle"/>
                </titleStyle>
                <textStyle ID="35" label="Slide Text" x="346.5"
                    y="281.5" width="107.0" height="37.0"
                    strokeWidth="0.0" autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-22</font>
                    <metadata-list category-list-size="0"
                        ontology-list-size="0" other-list-size="0" RCategoryListSize="0">
                        <ontology-list-string></ontology-list-string>
                    </metadata-list>
                    <URIString>http://vue.tufts.edu/rdf/resource/67ac67f10a14182f00e1cb28a9243de2</URIString>
                    <shape xsi:type="rectangle"/>
                </textStyle>
                <linkStyle ID="36" label="Links" x="373.5" y="384.0"
                    width="53.0" height="32.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#B3BFE3</textColor>
                    <font>Gill Sans-plain-18</font>
                    <metadata-list category-list-size="0"
                        ontology-list-size="0" other-list-size="0" RCategoryListSize="0">
                        <ontology-list-string></ontology-list-string>
                    </metadata-list>
                    <URIString>http://vue.tufts.edu/rdf/resource/67ac67f10a14182f00e1cb288bc7b958</URIString>
                    <shape xsi:type="rectangle"/>
                </linkStyle>
            </masterSlide>
        </pathway>
    </PathwayList>
    <date>2014-10-31</date>
    <mapFilterModel/>
    <modelVersion>5</modelVersion>
    <saveLocation>C:\Users\fullsail\Desktop</saveLocation>
    <saveFile>C:\Users\fullsail\Desktop\YetiSmall.vue</saveFile>
</LW-MAP>
