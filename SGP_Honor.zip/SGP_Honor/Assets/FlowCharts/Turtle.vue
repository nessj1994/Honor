<!-- Tufts VUE 2.3.1 concept-map (Turtle.vue) 2014-10-31 -->
<!-- Tufts VUE: http://vue.tufts.edu/ -->
<!-- Do Not Remove: VUE mapping @version(1.1) jar:file:/C:/Program%20Files%20(x86)/VUE/VUE.jar!/tufts/vue/resources/lw_mapping_1_1.xml -->
<!-- Do Not Remove: Saved date Fri Oct 31 15:35:56 EDT 2014 by Jordan on platform Windows 8 6.2 in JVM 1.7.0_40-b43 -->
<!-- Do Not Remove: Saving version @(#)VUE: built May 6 2009 at 1148 by vue on Linux 2.4.21-57.EL i386 JVM 1.5.0_06-b05 -->
<?xml version="1.0" encoding="US-ASCII"?>
<LW-MAP xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:noNamespaceSchemaLocation="none" ID="0" label="Turtle.vue"
    x="0.0" y="0.0" width="1.4E-45" height="1.4E-45" strokeWidth="0.0" autoSized="false">
    <resource referenceCreated="1414784156443" size="22571"
        spec="C:\Users\fullsail\Desktop\Turtle.vue" type="1" xsi:type="URLResource">
        <title>Turtle.vue</title>
        <property key="File" value="C:\Users\fullsail\Desktop\Turtle.vue"/>
    </resource>
    <fillColor>#FFFFFF</fillColor>
    <strokeColor>#404040</strokeColor>
    <textColor>#000000</textColor>
    <font>SansSerif-plain-14</font>
    <metadata-list category-list-size="1" ontology-list-size="0"
        other-list-size="0" RCategoryListSize="0">
        <ontology-list-string></ontology-list-string>
        <metadata xsi:type="vue-metadata-element">
            <value></value>
            <key>http://vue.tufts.edu/vue.rdfs#none</key>
            <type>1</type>
        </metadata>
    </metadata-list>
    <URIString>http://vue.tufts.edu/rdf/resource/67b43d120a14182f00e1cb28cec299ce</URIString>
    <child ID="2" label="Attack" layerID="1" x="463.0" y="71.0"
        width="90.0" height="42.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#EA2218</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67b43d130a14182f00e1cb281dd6d8f4</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="3" label="Movement" layerID="1" x="463.0" y="136.0"
        width="87.0" height="40.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67b43d130a14182f00e1cb28d59cecaf</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="4" label="Turtle" layerID="1" x="86.0" y="36.0"
        width="224.0" height="97.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#F2AE45</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67b43d140a14182f00e1cb289f31dcfa</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="5" label="Idle" layerID="1" x="148.0" y="211.0"
        width="87.0" height="40.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67b43d140a14182f00e1cb284e48d09b</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="6" label="Check Range" layerID="1" x="336.0" y="216.0"
        width="87.0" height="40.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67b43d150a14182f00e1cb284e1dae36</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="7" label="Hide" layerID="1" x="364.0" y="329.0"
        width="37.0" height="53.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67b43d150a14182f00e1cb286963f4d9</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="8" label="Shoot" layerID="1" x="526.0" y="381.0"
        width="90.0" height="32.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#EA2218</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67b43d160a14182f00e1cb286ebc3138</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="9" label="Check Cooldowns" layerID="1" x="673.0"
        y="213.0" width="112.0" height="42.0" strokeWidth="1.0"
        autoSized="false" xsi:type="node">
        <fillColor>#EA2218</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67b43d160a14182f00e1cb281b848b9f</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="12" label="Wait" layerID="1" x="686.0" y="377.0"
        width="90.0" height="42.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#EA2218</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67b43d170a14182f00e1cb28c708449c</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="13" label="Player Nearby" layerID="1" x="234.5" y="226.5"
        width="102.0" height="14.0" strokeWidth="1.0" autoSized="false"
        controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67b43d170a14182f00e1cb28a4d74b75</URIString>
        <point1 x="235.0" y="232.15692"/>
        <point2 x="336.0" y="234.8431"/>
        <ID1 xsi:type="node">5</ID1>
        <ID2 xsi:type="node">6</ID2>
    </child>
    <child ID="14" label="Attack Range" layerID="1" x="422.5"
        y="228.03577" width="251.0" height="14.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67b43d180a14182f00e1cb28c1c673e1</URIString>
        <point1 x="423.0" y="235.75107"/>
        <point2 x="673.0" y="234.32045"/>
        <ID1 xsi:type="node">6</ID1>
        <ID2 xsi:type="node">9</ID2>
    </child>
    <child ID="15" label="Too close" layerID="1" x="356.91843" y="255.5"
        width="48.0" height="74.0" strokeWidth="1.0" autoSized="false"
        controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67b43d190a14182f00e1cb2803bdbf6d</URIString>
        <point1 x="380.0021" y="256.0"/>
        <point2 x="381.83475" y="329.0"/>
        <ID1 xsi:type="node">6</ID1>
        <ID2 xsi:type="node">7</ID2>
    </child>
    <child ID="16" label="Hiding" layerID="1" x="400.5" y="255.5"
        width="44.757812" height="86.900665" strokeWidth="1.0"
        autoSized="false" controlCount="1" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67b43d190a14182f00e1cb282d9cd416</URIString>
        <point1 x="401.0" y="341.90067"/>
        <point2 x="404.03125" y="256.0"/>
        <ID1 xsi:type="node">7</ID1>
        <ID2 xsi:type="node">6</ID2>
        <ctrlPoint0 x="458.0" y="300.0" xsi:type="point"/>
    </child>
    <child ID="17" label="Attack on CD" layerID="1" x="698.0" y="254.5"
        width="64.0" height="123.0" strokeWidth="1.0" autoSized="false"
        controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67b43d1a0a14182f00e1cb28edcc3577</URIString>
        <point1 x="729.2561" y="255.0"/>
        <point2 x="730.7439" y="377.0"/>
        <ID1 xsi:type="node">9</ID1>
        <ID2 xsi:type="node">12</ID2>
    </child>
    <child ID="18" label="Attack off CD" layerID="1" x="586.00916"
        y="254.5" width="123.13495" height="127.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67b43d1f0a14182f00e1cb28e9752ea0</URIString>
        <point1 x="708.64417" y="255.0"/>
        <point2 x="586.5092" y="381.0"/>
        <ID1 xsi:type="node">9</ID1>
        <ID2 xsi:type="node">8</ID2>
    </child>
    <child ID="19" label="Waiting" layerID="1" x="758.66473" y="254.5"
        width="61.585327" height="123.0" strokeWidth="1.0"
        autoSized="false" controlCount="1" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67b43d1f0a14182f00e1cb28fba776a6</URIString>
        <point1 x="759.16473" y="377.0"/>
        <point2 x="759.8355" y="255.0"/>
        <ID1 xsi:type="node">12</ID1>
        <ID2 xsi:type="node">9</ID2>
        <ctrlPoint0 x="845.0" y="313.0" xsi:type="point"/>
    </child>
    <child ID="20" label="Done with shot" layerID="1" x="402.78882"
        y="255.5" width="149.68011" height="126.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67b43d200a14182f00e1cb28d8675e5f</URIString>
        <point1 x="551.96893" y="381.0"/>
        <point2 x="403.28882" y="256.0"/>
        <ID1 xsi:type="node">8</ID1>
        <ID2 xsi:type="node">6</ID2>
    </child>
    <child ID="25" label="Player Left Range" layerID="1" x="233.63896"
        y="202.15765" width="105.08946" height="18.310318"
        strokeWidth="1.0" autoSized="false" controlCount="1"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67b5032b0a14182f00e1cb28dae82d35</URIString>
        <point1 x="338.22842" y="219.96797"/>
        <point2 x="234.13896" y="216.996"/>
        <ID1 xsi:type="node">6</ID1>
        <ID2 xsi:type="node">5</ID2>
        <ctrlPoint0 x="286.3954" y="199.83333" xsi:type="point"/>
    </child>
    <layer ID="1" label="Layer 1" x="0.0" y="0.0" width="1.4E-45"
        height="1.4E-45" strokeWidth="0.0" autoSized="false">
        <metadata-list category-list-size="0" ontology-list-size="0"
            other-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/67b43d200a14182f00e1cb287015082f</URIString>
    </layer>
    <userZoom>1.0</userZoom>
    <userOrigin x="-12.0" y="-12.0"/>
    <presentationBackground>#202020</presentationBackground>
    <PathwayList currentPathway="0" revealerIndex="-1">
        <pathway ID="0" label="Untitled Pathway" x="0.0" y="0.0"
            width="1.4E-45" height="1.4E-45" strokeWidth="0.0"
            autoSized="false" currentIndex="-1" open="true">
            <strokeColor>#B3CC33CC</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="0" ontology-list-size="0"
                other-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/67b43d210a14182f00e1cb285ea58a71</URIString>
            <masterSlide ID="21" x="0.0" y="0.0" width="800.0"
                height="600.0" locked="true" strokeWidth="0.0" autoSized="false">
                <fillColor>#000000</fillColor>
                <strokeColor>#404040</strokeColor>
                <textColor>#000000</textColor>
                <font>SansSerif-plain-14</font>
                <metadata-list category-list-size="0"
                    ontology-list-size="0" other-list-size="0" RCategoryListSize="0">
                    <ontology-list-string></ontology-list-string>
                </metadata-list>
                <URIString>http://vue.tufts.edu/rdf/resource/67b43d360a14182f00e1cb2858bd652c</URIString>
                <titleStyle ID="22" label="Header" x="335.5" y="172.5"
                    width="129.0" height="55.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-36</font>
                    <metadata-list category-list-size="0"
                        ontology-list-size="0" other-list-size="0" RCategoryListSize="0">
                        <ontology-list-string></ontology-list-string>
                    </metadata-list>
                    <URIString>http://vue.tufts.edu/rdf/resource/67b43d370a14182f00e1cb2859e977aa</URIString>
                    <shape xsi:type="rectangle"/>
                </titleStyle>
                <textStyle ID="23" label="Slide Text" x="346.5"
                    y="281.5" width="107.0" height="37.0"
                    strokeWidth="0.0" autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-22</font>
                    <metadata-list category-list-size="0"
                        ontology-list-size="0" other-list-size="0" RCategoryListSize="0">
                        <ontology-list-string></ontology-list-string>
                    </metadata-list>
                    <URIString>http://vue.tufts.edu/rdf/resource/67b43d370a14182f00e1cb282b1f10ae</URIString>
                    <shape xsi:type="rectangle"/>
                </textStyle>
                <linkStyle ID="24" label="Links" x="373.5" y="384.0"
                    width="53.0" height="32.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#B3BFE3</textColor>
                    <font>Gill Sans-plain-18</font>
                    <metadata-list category-list-size="0"
                        ontology-list-size="0" other-list-size="0" RCategoryListSize="0">
                        <ontology-list-string></ontology-list-string>
                    </metadata-list>
                    <URIString>http://vue.tufts.edu/rdf/resource/67b43d370a14182f00e1cb2837d3a41c</URIString>
                    <shape xsi:type="rectangle"/>
                </linkStyle>
            </masterSlide>
        </pathway>
    </PathwayList>
    <date>2014-10-31</date>
    <mapFilterModel/>
    <modelVersion>5</modelVersion>
    <saveLocation>C:\Users\fullsail\Desktop</saveLocation>
    <saveFile>C:\Users\fullsail\Desktop\Turtle.vue</saveFile>
</LW-MAP>
