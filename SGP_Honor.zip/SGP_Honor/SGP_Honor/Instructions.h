#pragma once
class Instructions
{
public:
	Instructions();
	~Instructions();
};

