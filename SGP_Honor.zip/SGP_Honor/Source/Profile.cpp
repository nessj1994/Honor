#include "Profile.h"


Profile::Profile(int number)
{
	m_nNumber = number;
}


Profile::~Profile()
{
}
