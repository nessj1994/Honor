#include "Frame.h"


Frame::Frame()
{
}


Frame::~Frame()
{
}
