#pragma once
class World
{
public:
	World();
	~World();
};

