#pragma once
class AnchorPointAnimation
{
public:
	AnchorPointAnimation();
	~AnchorPointAnimation();
};

