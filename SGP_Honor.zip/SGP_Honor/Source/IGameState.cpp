#include "IGameState.h"



IGameState::IGameState()
{
}


IGameState::~IGameState()
{
}

void IGameState::Enter()
{

}
void IGameState::Exit()
{

}
void IGameState::Update(float elapsedTime)
{

}
void IGameState::Render()
{

}