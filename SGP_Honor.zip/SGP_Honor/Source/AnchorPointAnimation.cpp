#include "AnchorPointAnimation.h"


AnchorPointAnimation::AnchorPointAnimation()
{
}


AnchorPointAnimation::~AnchorPointAnimation()
{
}
