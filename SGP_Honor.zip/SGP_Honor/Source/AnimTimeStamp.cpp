#include "AnimTimeStamp.h"


AnimTimeStamp::AnimTimeStamp()
{
}


AnimTimeStamp::~AnimTimeStamp()
{
}
