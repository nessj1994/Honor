#include "Letter.h"


Letter::Letter()
{
}


Letter::~Letter()
{
}
